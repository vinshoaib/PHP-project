<?php
class User{
 
    // database connection and table name
    private $conn;
    private $table_name = "users";
    private $table_user = "profile";
 
    // object properties
    public $id;
    public $email;
    public $phone;
    public $password;
    public $created;

    public $fname;

    public $lname;
    public $role;
 
    // constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }
    // signup user
    function signup(){
    
        if($this->isAlreadyExist()){
            return false;
        }
        // query to insert record
        $query = "INSERT INTO
                    " . $this->table_name . "
                SET
                    email=:email,phone=:phone ,password=:password, created=:created";
    
        // prepare query
        $stmt = $this->conn->prepare($query);
    
        // sanitize
        $this->email=htmlspecialchars(strip_tags($this->email));
        $this->phone=htmlspecialchars(strip_tags($this->phone));
        $this->password=htmlspecialchars(strip_tags($this->password));
        $this->created=htmlspecialchars(strip_tags($this->created));
    
        // bind values
        $stmt->bindParam(":email", $this->email);
        $stmt->bindParam(":phone", $this->phone);
        $stmt->bindParam(":password", $this->password);
        $stmt->bindParam(":created", $this->created);
    
        // execute query
        if($stmt->execute()){
            $this->id = $this->conn->lastInsertId();
            return true;
        }
    
        return false;
        
    }
    // login user
    function login(){
        // select all query
        $query = "SELECT
                    `id`, `email`, `password`, `created`
                FROM
                    " . $this->table_name . " 
                WHERE
                    email='".$this->email."' AND password='".$this->password."'";
        // prepare query statement
        $stmt = $this->conn->prepare($query);
        // execute query
        $stmt->execute();
        return $stmt;
    }
    function isAlreadyExist(){
        $query = "SELECT *
            FROM
                " . $this->table_name . " 
            WHERE
                email='".$this->email."'";
        // prepare query statement
        $stmt = $this->conn->prepare($query);
        // execute query
        $stmt->execute();
        if($stmt->rowCount() > 0){
            return true;
        }
        else{
            return false;
        }
    }

    function show(){ $query = "SELECT *
        FROM
            " . $this->table_user . " 
        WHERE
            id='".$this->id."'";
    // prepare query statement
    $stmt = $this->conn->prepare($query);
    // execute query
    $stmt->execute();
    if($stmt->rowCount() > 0){
        return $stmt;
    }
    else{
        return false;
    }

    }
    function create(){
    
        
        $query = "INSERT INTO
                    " . $this->table_user . "
                SET
                    id=:id,fname=:fname,lname=:lname, role=:role";
    
        // prepare query
        $stmt = $this->conn->prepare($query);
    
        // sanitize
        $this->id=htmlspecialchars(strip_tags($this->id));
        $this->fname=htmlspecialchars(strip_tags($this->fname));
        $this->lname=htmlspecialchars(strip_tags($this->lname));
        $this->role=htmlspecialchars(strip_tags($this->role));
    
        // bind values
        $stmt->bindParam(":id", $this->id);
        $stmt->bindParam(":fname", $this->fname);
        $stmt->bindParam(":lname", $this->lname);
        $stmt->bindParam(":role", $this->role);
    
        // execute query
        if($stmt->execute()){
            $this->id = $this->conn->lastInsertId();
            return true;
        }
    
    }
    function update(){
    
       
        // query to insert record
        $query = "UPDATE
                    " . $this->table_user . "
                SET
                fname=:fname,lname=:lname, role=:role where id=:id";
    
                // prepare query
                $stmt = $this->conn->prepare($query);
            
                // sanitize
                $this->id=htmlspecialchars(strip_tags($this->id));
                $this->fname=htmlspecialchars(strip_tags($this->fname));
                $this->lname=htmlspecialchars(strip_tags($this->lname));
                $this->role=htmlspecialchars(strip_tags($this->role));
            
                // bind values
                $stmt->bindParam(":id", $this->id);
                $stmt->bindParam(":fname", $this->fname);
                $stmt->bindParam(":lname", $this->lname);
                $stmt->bindParam(":role", $this->role);
            
                // execute query
                if($stmt->execute()){
                    $this->id = $this->conn->lastInsertId();
                    return true;
                }
        
    }
}