<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>PHP Learning</title>
  
  
  <link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Open+Sans:600'>
      <link rel="stylesheet" href="../../assets/css/style.css">
  
</head>
<body>
    <?php include("header.php") ?>
  <div class="login-wrap">
  <div class="login-html">
   
    <input id="tab-1" type="radio" name="tab" class="sign-up" checked><label for="tab-1" class="tab">Update Your Profile</label>
    
    <div class="login-form">
     
      <form class="sign-up-htm" action="updates.php" method="POST">
        <input id="id" name="id" type="text" value='<?php echo $_GET['id'] ?> ' style="display: none;"class="input">
        <div class="group">
          <label for="fname" class="label">First Name</label>
          <input id="fname" name="fname" type="text" class="input">
        </div>
        <div class="group">
          <label for="lname" class="label">Last Name</label>
          <input id="lname" name="lname" type="text" class="input">
        </div>
        <div class="group">
            <label for="role" class="label">Role</label>
<div class="form-check">
            <input class="form-check-input" type="radio"value="Editor" name="role" id="role1">
            <label class="form-check-label" for="role1">
             Editor
            </label>
          </div>
          <div class="form-check">
            <input class="form-check-input" type="radio" value="Writer" name="role" id="role2" >
            <label class="form-check-label" for="role2">
              Writer
            </label>
          </div><br>
     
        <div class="group">
          <input type="submit" class="button" value="Create">
        </div>
        <div class="hr"></div>
        <div class="foot-lnk">
        </div>
      </form>
    </div>
  </div>
</div>
  
  
</body>
</html>