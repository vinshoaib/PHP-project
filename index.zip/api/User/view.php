<?php $id = $_GET['id'];
include("header.php") ?>


    <div class="container">
    <div class="row">
    <table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Create</th>
      <th scope="col">Read</th>
      <th scope="col">Update</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td><button type="button" class="btn btn-primary"><a href="creates.php?<?php echo"id=$id"?>" style="color:inherit;text-decoration:none">Create</a></button></td>
      <td><a href="read.php?<?php echo"id=$id"?>" style="color:inherit;text-decoration:none">
<button type="button" class="btn btn-info">Read</button></a></td>
      <td><a href="update.php?<?php echo"id=$id"?>" style="color:inherit;text-decoration:none">
<button type="button" class="btn btn-success">Update</button></a></td>
    </tr>
    
  </tbody>
</table>
    </div>

    </div>

    </body>
</html>