<?php
// include database and object files
include_once '../config/database.php';
include_once '../objects/user.php';
  
// POST database connection
$database = new Database();
$db = $database->GetConnection();

// prepare user object
$user = new User($db);
// set ID property of user to be edited
$user->email = isset($_POST['email']) ? $_POST['email'] : die();
$user->password = base64_encode(isset($_POST['password']) ? $_POST['password'] : die());
// read the details of user to be edited
$stmt = $user->login();
if($stmt->rowCount() > 0){
    // POST retrieved row
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    // create array
    $user_arr=$row['email'];
    $id = $row["id"];
    header("Location:view.php?id=$id");
}
else{
    $user_arr=array(
        "status" => false,
        "message" => "Invalid email or Password!",
    );
}
// make it json format

?>