
<?php
 
// get database connection
include_once '../config/database.php';
 
// instantiate user object
include_once '../objects/user.php';
$id;
$database = new Database();
$db = $database->getConnection();
 
$user = new User($db);
 
// set user property values
$user->id = $_GET['id'];
 
// create the user
$stmt = $user->show();
if($stmt->rowCount() > 0){
    // POST retrieved row
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    // create array
    $f=$row['fname'];
    $l=$row['lname'];
    $role=$row['role'];


    $id = $row["id"];
    // header("Location:view.php?id=$id");
}
else{
    $user_arr=array(
        "status" => false,
        "message" => "Username already existsssssssss!"
    );
}
// print_r(json_encode($user_arr));

include("header.php")?>
    <div class="container">
    <div class="row">
    <table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">First Name</th>
      <th scope="col">Last Name</th>
      <th scope="col">Role</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td><?php echo $f; ?></td>
      <td><?php echo $l; ?></td>
      <td><?php echo $role; ?></td>
    </tr>
    
  </tbody>
</table>
    </div>

    </div>

    </body>
</html>