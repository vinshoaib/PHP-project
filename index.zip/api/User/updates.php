<?php
 
// get database connection
include_once '../config/database.php';
 
// instantiate user object
include_once '../objects/user.php';
$id=$_GET['id'];
$database = new Database();
$db = $database->getConnection();
 
$user = new User($db);
 
// set user property values
$user->fname = $_POST['fname'];
$user->lname = $_POST['lname'];
$user->role = $_POST['role'];
$user->id = $_POST['id'];
 
// create the user
if($user->update()){
    $user_arr=array(
        "status" => true,
        "message" => "Successfully Created!",
        "id" => $user->id,
        "email" => $user->email

    );
    header("Location:view.php?id=$id");
}
else{
    $user_arr=array(
        "status" => false,
        "message" => "Username already existsssssssss!"
    );
}
print_r(json_encode($user_arr));
?>